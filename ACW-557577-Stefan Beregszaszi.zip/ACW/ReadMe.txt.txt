Camera Controls - w/a/s/d (forward,left,bacwards,right)

                 - u (Turn on/off animation)

                  - q/e (rotate plane to left or right)

                   - z/c (rotate model to the left or right)

                    - t/g (ascend/descend camera)